<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

  <style type="text/css">
    .div_center {
      text-align: center;
      padding: 40px;
    }

    .center {
      margin: auto;
      width: 50%;
      text-align: center;
      border: 3px solid white;
    }
    label
    {
        display: inline-block;
        width: 200px;
    }
  </style>
</head>

<body>
  <div class="container-scroller">
    <!-- partial:partials/_sidebar.html -->
    <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <!-- partial -->
    <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <!-- partial -->

    <!-- content-wrapper ends -->
    <!-- partial:partials/_footer.html -->

    <div class="main-panel">
      <div class="content-wrapper">

      <div class="div_center">
        <h1>Add Product</h1>

        <form action="<?php echo e(url('/add_product')); ?>" method="POST" enctype="multipart/form-data">

        <?php echo csrf_field(); ?>

        <div class="div_design">
            <label>Product Title: </label>
            <input type="text" name="title" placeholder="Write a title">
        </div>
        <div  class="div_design">
            <label>Product Description: </label>
            <input type="text" name="description" placeholder="Write a Description">
        </div>
        <div class="div_design" >
            <label>Product price: </label>
            <input type="number" name="price" placeholder="Write a title">
        </div>
        <div class="div_design">
            <label>Discount: </label>
            <input type="number" name="dis_price" placeholder="Write a title">
        </div>
        <div class="div_design">
            <label>Product Quanitity: </label>
            <input type="number" name="quantity" min="0" placeholder="Write a title">
        </div>
     
        <div class="div_design">
                            <label>Categories: </label><br>
                            <?php $__currentLoopData = $catagory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catagory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <input type="checkbox" name="catagories[]" value="<?php echo e($catagory->id); ?>"> <?php echo e($catagory->catagory_name); ?><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
        <div class="div_design">
            <label>Product image: </label>
            <input type="file" name="image">
        </div>

        <div>
            <input type="submit" value="Submit" class="btn btn-primary">
        </div>
   

        </form>


      </div>

</div>
</div>
    
 
  </div>
  <!-- container-scroller -->
  <!-- plugins:js -->
  <?php echo $__env->make('admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
</body>

</html><?php /**PATH C:\Users\chathu s mapa\Desktop\CODE\java\New folder\shopingAppLaravel\EcommerceSystem\resources\views/admin/product.blade.php ENDPATH**/ ?>