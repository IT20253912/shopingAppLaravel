<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

  <style type="text/css">
    .div_center {
      text-align: center;
      padding: 40px;
    }

    .center {
      margin: auto;
      width: 50%;
      text-align: center;
      border: 3px solid white;
    }
  </style>
</head>

<body>
  <div class="container-scroller">
    <!-- partial:partials/_sidebar.html -->
    <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <!-- partial -->
    <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <!-- partial -->

    <!-- content-wrapper ends -->
    <!-- partial:partials/_footer.html -->
    <div class="main-panel">
      <div class="content-wrapper">

        <?php if(session()->has('message')): ?>

        <div class="alert alert-success">
          <button type="buttton" class="close" data-dismiss="alert" aria-hidden="true">x</button>
          <?php echo e(session()->get('message')); ?>

        </div>

        <?php endif; ?>

        <div class="div_center">
          <h2>Add Catagory</h2>



          <form action="<?php echo e(url('/add_catagory')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="text" name="catagory" placeholder="write category name">
            <select name="parent_id">
              <option value="">Main Category</option>
              <?php $__currentLoopData = $mainCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($category->id); ?>"><?php echo e($category->catagory_name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <input type="submit" value="Add" class="btn btn-primary" name="submit">
          </form>



        </div>

       <!-- catagory.blade.php -->
<table class="center">
    <tr>
        <td>Category name</td>
        <td>Action</td>
    </tr>
    <?php $__currentLoopData = $mainCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mainCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($mainCategory->catagory_name); ?></td>
            <td>
                <a class="btn btn-primary" href="<?php echo e(route('edit_category', $mainCategory->id)); ?>">Edit</a>
                <a class="btn btn-danger" href="<?php echo e(url('delete_catagory', $mainCategory->id)); ?>">Delete</a>
            </td>
        </tr>
        <?php $__currentLoopData = $mainCategory->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>-- <?php echo e($subCategory->catagory_name); ?></td>
                <td>
                    <a class="btn btn-primary" href="<?php echo e(route('edit_category', $subCategory->id)); ?>">Edit</a>
                    <a class="btn btn-danger" href="<?php echo e(url('delete_catagory', $subCategory->id)); ?>">Delete</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>








      </div>

    </div>
    <!-- partial -->
  </div>
  <!-- main-panel ends -->
  </div>
  <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- plugins:js -->
  <?php echo $__env->make('admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
</body>

</html><?php /**PATH C:\Users\chathu s mapa\Desktop\CODE\java\New folder\shopingAppLaravel\EcommerceSystem\resources\views/admin/catagory.blade.php ENDPATH**/ ?>